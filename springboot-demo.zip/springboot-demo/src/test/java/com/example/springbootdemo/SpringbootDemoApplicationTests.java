package com.example.springbootdemo;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDemoApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}

}
